"""Setup configuration for ThreatLens."""

from setuptools import find_packages, setup

setup(
    name="threatlens",
    version="1.0.0",
    description="Log Analysis & Threat Hunting CLI",
    author="Jude Hilgendorf",
    python_requires=">=3.10",
    packages=find_packages(),
    install_requires=[
        "pyyaml>=6.0",
    ],
    entry_points={
        "console_scripts": [
            "threatlens=threatlens.cli:main",
        ],
    },
)
