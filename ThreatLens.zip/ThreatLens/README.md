# ThreatLens

**Log Analysis & Threat Hunting CLI for Security Analysts**

ThreatLens is a Python-based command-line tool that parses Windows Security and Sysmon logs, runs detection rules against them, and generates actionable alerts mapped to the MITRE ATT&CK framework. Built for SOC analysts, incident responders, and anyone learning blue-team fundamentals.

---

## Why ThreatLens?

Security teams deal with thousands of log events daily. ThreatLens automates the first pass of analysis — detecting brute-force attacks, lateral movement, privilege escalation, and suspicious process execution — so analysts can focus on investigation instead of scrolling through raw logs.

---

## Features

- **Brute-Force / Password Spray Detection** — Identifies bursts of failed logons from a single source, distinguishing targeted brute-force from password spray attacks
- **Lateral Movement Detection** — Flags accounts authenticating to multiple hosts in a short window (network logons, RDP)
- **Privilege Escalation Detection** — Catches sensitive privilege assignments (SeDebugPrivilege, SeTcbPrivilege) to non-system accounts
- **Suspicious Process Detection** — Pattern-matches LOLBins and malicious command-line signatures (encoded PowerShell, certutil download cradles, SAM dumping)
- **MITRE ATT&CK Mapping** — Every alert links to the relevant tactic and technique
- **JSON & CSV Export** — Output reports for further analysis or SIEM ingestion
- **Configurable Thresholds** — Tune detection sensitivity via YAML config
- **Sample Data Included** — Demo the tool immediately with realistic attack scenarios

---

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/ThreatLens.git
cd ThreatLens

# Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate    # Linux/macOS
.venv\Scripts\activate       # Windows

# Install dependencies
pip install -r requirements.txt

# Install ThreatLens as a CLI tool
pip install -e .
```

**Requirements:** Python 3.10+

---

## Usage

### Scan a log file

```bash
threatlens scan sample_data/sample_security_log.json
```

### Scan with verbose output (show evidence)

```bash
threatlens scan sample_data/sample_security_log.json --verbose
```

### Filter by minimum severity

```bash
threatlens scan sample_data/sample_security_log.json --min-severity high
```

### Export to JSON report

```bash
threatlens scan sample_data/sample_security_log.json --output report.json --format json
```

### Export to CSV

```bash
threatlens scan sample_data/sample_security_log.json --output report.csv --format csv
```

### Scan an entire directory of log files

```bash
threatlens scan /path/to/logs/
```

### List available detection rules

```bash
threatlens rules
```

### Run directly without installing

```bash
python -m threatlens.cli scan sample_data/sample_security_log.json
```

---

## Example Output

```
  _____ _                    _   _
 |_   _| |__  _ __ ___  __ _| |_| |    ___ _ __  ___
   | | | '_ \| '__/ _ \/ _` | __| |   / _ \ '_ \/ __|
   | | | | | | | |  __/ (_| | |_| |__|  __/ | | \__ \
   |_| |_| |_|_|  \___|\__,_|\__|_____\___|_| |_|___/

  Log Analysis & Threat Hunting CLI v1.0.0

  Scanning 1 file(s)...

  Parsed     26 events from sample_security_log.json

============================================================
  SCAN SUMMARY
============================================================
  Events analyzed:   26
  Alerts generated:  9
  Scan duration:     0.01s

  CRITICAL     2
  HIGH         4
  MEDIUM       2
  LOW          1
============================================================

  [CRITICAL] Suspicious Process: SAM registry hive access
    Time:       2025-01-15 09:15:00
    Detail:     Process 'reg.exe' executed with suspicious command line on DC-01 by jdoe
    MITRE:      Execution / T1059 - Command and Scripting Interpreter
    Action:     Review the full command line and parent process...

  [HIGH] Brute-Force Detected
    Time:       2025-01-15 08:30:01
    Detail:     7 failed logon attempts from 10.0.1.50 targeting 1 account(s) within 300s
    MITRE:      Credential Access / T1110 - Brute Force
    Action:     Investigate source 10.0.1.50. Consider blocking the IP...
```

---

## Project Structure

```
ThreatLens/
├── threatlens/
│   ├── __init__.py              # Package metadata
│   ├── cli.py                   # Argument parsing and command routing
│   ├── parser.py                # JSON log parsing and normalization
│   ├── models.py                # LogEvent, Alert, Severity data models
│   ├── report.py                # Terminal output, JSON/CSV export
│   ├── utils.py                 # Shared helpers (tables, colors, grouping)
│   └── detections/
│       ├── __init__.py          # Detection registry
│       ├── base.py              # Abstract DetectionRule base class
│       ├── brute_force.py       # Failed logon burst detection
│       ├── lateral_movement.py  # Multi-host authentication patterns
│       ├── privilege_escalation.py  # Sensitive privilege monitoring
│       └── suspicious_process.py    # LOLBin and command-line analysis
├── rules/
│   └── default_rules.yaml       # Configurable detection thresholds
├── sample_data/
│   └── sample_security_log.json # Realistic sample with attack scenarios
├── tests/
│   └── test_detections.py       # Comprehensive test suite
├── setup.py
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

---

## Running Tests

```bash
pytest tests/ -v
```

---

## Log Format

ThreatLens accepts JSON-formatted logs — either a JSON array or newline-delimited JSON (NDJSON). The expected schema mirrors Windows Event Log JSON exports:

```json
{
  "TimeCreated": "2025-01-15T08:30:01Z",
  "EventID": 4625,
  "Computer": "WS-PC01",
  "EventData": {
    "TargetUserName": "admin",
    "IpAddress": "10.0.1.50",
    "LogonType": 3
  }
}
```

You can export Windows Event Logs to this format using PowerShell:

```powershell
Get-WinEvent -LogName Security -MaxEvents 1000 |
  Select-Object TimeCreated, Id, MachineName, Message |
  ConvertTo-Json | Out-File security_events.json
```

---

## Security & Ethics

ThreatLens is a **defensive** security tool. It analyzes logs that already exist on systems you own or are authorized to audit. It does not:

- Access remote systems
- Capture network traffic
- Exploit vulnerabilities
- Generate attack traffic

Use this tool only on systems and logs you have explicit authorization to analyze.

---

## Roadmap

- [ ] EVTX native parsing (read Windows Event Log files directly)
- [ ] YAML-based custom rule engine (user-defined detection rules)
- [ ] Sigma rule compatibility layer
- [ ] HTML report generation with charts
- [ ] Real-time log tailing mode (`--follow`)
- [ ] Syslog/CEF input format support
- [ ] Elasticsearch output connector
- [ ] Timeline visualization of attack chains

---

## License

MIT License. See [LICENSE](LICENSE) for details.
