"""ThreatLens command-line interface."""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from threatlens.detections import ALL_DETECTORS
from threatlens.models import Severity
from threatlens.parser import load_events
from threatlens.report import (
    export_csv,
    export_json,
    print_alerts,
    print_banner,
    print_summary,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="threatlens",
        description="ThreatLens - Log Analysis & Threat Hunting CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  threatlens scan logs/security.json\n"
            "  threatlens scan logs/ --output report.json --format json\n"
            "  threatlens scan events.json --min-severity high --verbose\n"
            "  threatlens rules\n"
        ),
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- scan command ---
    scan_parser = subparsers.add_parser("scan", help="Analyze log files for threats")
    scan_parser.add_argument(
        "path",
        type=str,
        help="Path to a JSON log file or directory of JSON files",
    )
    scan_parser.add_argument(
        "--output", "-o",
        type=str,
        default=None,
        help="Output file path for the report",
    )
    scan_parser.add_argument(
        "--format", "-f",
        choices=["json", "csv"],
        default="json",
        help="Output format (default: json)",
    )
    scan_parser.add_argument(
        "--min-severity",
        choices=["low", "medium", "high", "critical"],
        default="low",
        help="Minimum severity level to report (default: low)",
    )
    scan_parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed evidence for each alert",
    )
    scan_parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress banner and only show alerts",
    )

    # --- rules command ---
    subparsers.add_parser("rules", help="List all available detection rules")

    return parser


def collect_log_files(path: Path) -> list[Path]:
    """Gather all JSON log files from a file or directory path."""
    if path.is_file():
        return [path]
    if path.is_dir():
        files = sorted(path.glob("*.json")) + sorted(path.glob("*.ndjson"))
        return files
    return []


def run_scan(args: argparse.Namespace) -> int:
    """Execute the scan command."""
    target = Path(args.path)
    log_files = collect_log_files(target)

    if not log_files:
        print(f"Error: No JSON log files found at '{args.path}'", file=sys.stderr)
        return 1

    if not args.quiet:
        print_banner()
        print(f"  Scanning {len(log_files)} file(s)...\n")

    # Parse all events
    all_events = []
    for log_file in log_files:
        try:
            events = load_events(log_file)
            all_events.extend(events)
            if not args.quiet:
                print(f"  Parsed {len(events):>6,} events from {log_file.name}")
        except Exception as e:
            print(f"  Warning: Failed to parse {log_file.name}: {e}", file=sys.stderr)

    if not all_events:
        print("Error: No events could be parsed from the input files.", file=sys.stderr)
        return 1

    all_events.sort(key=lambda e: e.timestamp)

    # Run detections
    start_time = time.time()
    all_alerts = []

    for detector_cls in ALL_DETECTORS:
        detector = detector_cls()
        try:
            alerts = detector.analyze(all_events)
            all_alerts.extend(alerts)
        except Exception as e:
            print(f"  Warning: Detector '{detector.name}' failed: {e}", file=sys.stderr)

    elapsed = time.time() - start_time

    # Filter by minimum severity
    severity_order = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
    min_sev = Severity(args.min_severity)
    min_index = severity_order.index(min_sev)
    filtered = [a for a in all_alerts if severity_order.index(a.severity) >= min_index]

    # Display results
    print_summary(filtered, len(all_events), elapsed)
    print_alerts(filtered, verbose=args.verbose)

    # Export if requested
    if args.output:
        output_path = Path(args.output)
        if args.format == "csv":
            export_csv(filtered, output_path)
        else:
            export_json(filtered, output_path, len(all_events))
        print(f"  Report saved to {output_path}\n")

    # Return non-zero if critical alerts found
    has_critical = any(a.severity == Severity.CRITICAL for a in filtered)
    return 2 if has_critical else 0


def run_rules() -> int:
    """List all available detection rules."""
    print_banner()
    print("  Available Detection Rules:\n")
    for detector_cls in ALL_DETECTORS:
        d = detector_cls()
        print(f"  - {d.name}")
        print(f"    {d.description}")
        if d.mitre_technique:
            print(f"    MITRE: {d.mitre_tactic} / {d.mitre_technique}")
        print()
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "scan":
        return run_scan(args)
    elif args.command == "rules":
        return run_rules()
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
