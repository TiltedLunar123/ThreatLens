"""Detection modules for ThreatLens."""

from threatlens.detections.base import DetectionRule
from threatlens.detections.brute_force import BruteForceDetector
from threatlens.detections.lateral_movement import LateralMovementDetector
from threatlens.detections.privilege_escalation import PrivilegeEscalationDetector
from threatlens.detections.suspicious_process import SuspiciousProcessDetector

ALL_DETECTORS: list[type[DetectionRule]] = [
    BruteForceDetector,
    LateralMovementDetector,
    PrivilegeEscalationDetector,
    SuspiciousProcessDetector,
]

__all__ = [
    "DetectionRule",
    "ALL_DETECTORS",
    "BruteForceDetector",
    "LateralMovementDetector",
    "PrivilegeEscalationDetector",
    "SuspiciousProcessDetector",
]
