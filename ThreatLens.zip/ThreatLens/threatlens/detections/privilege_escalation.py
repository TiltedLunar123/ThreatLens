"""Detect potential privilege escalation activity."""

from __future__ import annotations

from typing import Any

from threatlens.detections.base import DetectionRule
from threatlens.models import Alert, LogEvent, Severity

# Sensitive privilege constants (Windows well-known privileges)
SENSITIVE_PRIVILEGES = {
    "SeDebugPrivilege",
    "SeTcbPrivilege",
    "SeAssignPrimaryTokenPrivilege",
    "SeLoadDriverPrivilege",
    "SeBackupPrivilege",
    "SeRestorePrivilege",
    "SeTakeOwnershipPrivilege",
    "SeImpersonatePrivilege",
}

# Accounts that normally receive elevated privileges (reduce noise)
SYSTEM_ACCOUNTS = {"SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "DWM-1", "UMFD-0"}

PRIV_EVENT_IDS = {4672, 4673, 4674}


class PrivilegeEscalationDetector(DetectionRule):
    """Detects unusual privilege assignments or usage.

    Flags when non-system accounts receive sensitive privileges like
    SeDebugPrivilege, which attackers use for credential dumping.
    """

    name = "Privilege Escalation"
    description = "Sensitive privilege assigned to non-system account"
    mitre_tactic = "Privilege Escalation"
    mitre_technique = "T1134 - Access Token Manipulation"

    def analyze(self, events: list[LogEvent]) -> list[Alert]:
        priv_events = [e for e in events if e.event_id in PRIV_EVENT_IDS]
        if not priv_events:
            return []

        alerts: list[Alert] = []

        for event in priv_events:
            user = event.username or event.target_username
            if not user or user.upper() in SYSTEM_ACCOUNTS:
                continue

            # Check if any sensitive privileges are mentioned in raw data
            raw_str = str(event.raw)
            found_privs = [p for p in SENSITIVE_PRIVILEGES if p in raw_str]

            if not found_privs:
                continue

            is_debug = "SeDebugPrivilege" in found_privs
            severity = Severity.HIGH if is_debug else Severity.MEDIUM

            evidence = [{
                "timestamp": event.timestamp_str,
                "username": user,
                "computer": event.computer,
                "event_id": event.event_id,
                "privileges": found_privs,
            }]

            alerts.append(Alert(
                rule_name="Suspicious Privilege Assignment",
                severity=severity,
                description=(
                    f"User '{user}' was assigned sensitive privileges: "
                    f"{', '.join(found_privs)}"
                ),
                timestamp=event.timestamp,
                evidence=evidence,
                mitre_tactic=self.mitre_tactic,
                mitre_technique=self.mitre_technique,
                recommendation=(
                    f"Verify that '{user}' requires these privileges. "
                    f"SeDebugPrivilege in particular is used by tools like "
                    f"Mimikatz for credential dumping."
                ),
            ))

        return alerts
