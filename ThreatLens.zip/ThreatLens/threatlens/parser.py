"""Log parser that normalizes raw JSON log entries into LogEvent objects."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Iterator

from threatlens.models import EventCategory, LogEvent

# Map Windows Security Event IDs to categories
EVENT_CATEGORY_MAP: dict[int, EventCategory] = {
    # Authentication events
    4624: EventCategory.AUTHENTICATION,  # Successful logon
    4625: EventCategory.AUTHENTICATION,  # Failed logon
    4634: EventCategory.AUTHENTICATION,  # Logoff
    4648: EventCategory.AUTHENTICATION,  # Explicit credential logon
    4776: EventCategory.AUTHENTICATION,  # Credential validation
    # Process events
    1: EventCategory.PROCESS,    # Sysmon - Process creation
    4688: EventCategory.PROCESS,  # Process creation
    4689: EventCategory.PROCESS,  # Process termination
    # Privilege events
    4672: EventCategory.PRIVILEGE,  # Special privileges assigned
    4673: EventCategory.PRIVILEGE,  # Privileged service called
    4674: EventCategory.PRIVILEGE,  # Operation attempted on privileged object
    # Network events
    3: EventCategory.NETWORK,    # Sysmon - Network connection
    5156: EventCategory.NETWORK,  # Network connection allowed
    5157: EventCategory.NETWORK,  # Network connection blocked
    # File events
    11: EventCategory.FILE,      # Sysmon - File created
    4663: EventCategory.FILE,    # Object access attempt
    # Registry events
    12: EventCategory.REGISTRY,  # Sysmon - Registry object added/deleted
    13: EventCategory.REGISTRY,  # Sysmon - Registry value set
}


def classify_event(event_id: int) -> EventCategory:
    return EVENT_CATEGORY_MAP.get(event_id, EventCategory.UNKNOWN)


def parse_timestamp(raw_ts: str) -> datetime:
    """Parse common timestamp formats from log sources."""
    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%m/%d/%Y %I:%M:%S %p",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(raw_ts, fmt)
        except ValueError:
            continue
    raise ValueError(f"Unable to parse timestamp: {raw_ts}")


def _extract_field(entry: dict, *keys: str, default: str = "") -> str:
    """Try multiple possible field names, return first match."""
    for key in keys:
        val = entry.get(key)
        if val is not None:
            return str(val)
        # Check nested EventData dict (common in Windows Event Log JSON exports)
        event_data = entry.get("EventData", {})
        if isinstance(event_data, dict):
            val = event_data.get(key)
            if val is not None:
                return str(val)
    return default


def parse_event(entry: dict) -> LogEvent:
    """Parse a single raw JSON log entry into a LogEvent."""
    event_id = int(_extract_field(entry, "EventID", "event_id", "EventId", default="0"))
    category = classify_event(event_id)

    ts_raw = _extract_field(
        entry, "TimeCreated", "timestamp", "Timestamp", "@timestamp", "time"
    )
    try:
        timestamp = parse_timestamp(ts_raw)
    except ValueError:
        timestamp = datetime.min

    return LogEvent(
        timestamp=timestamp,
        event_id=event_id,
        source=_extract_field(entry, "Source", "source", "Provider", "Channel"),
        category=category,
        computer=_extract_field(entry, "Computer", "computer", "ComputerName"),
        raw=entry,
        username=_extract_field(entry, "TargetUserName", "SubjectUserName", "User", "username"),
        domain=_extract_field(entry, "TargetDomainName", "SubjectDomainName", "Domain", "domain"),
        source_ip=_extract_field(entry, "IpAddress", "SourceAddress", "source_ip", "src_ip"),
        process_name=_extract_field(entry, "NewProcessName", "Image", "ProcessName", "process"),
        command_line=_extract_field(entry, "CommandLine", "command_line", "ParentCommandLine"),
        logon_type=int(_extract_field(entry, "LogonType", "logon_type", default="0")),
        status=_extract_field(entry, "Status", "status", "Keywords"),
        parent_process=_extract_field(entry, "ParentImage", "ParentProcessName", "parent_process"),
        target_username=_extract_field(entry, "TargetUserName", "target_user"),
    )


def load_events(log_path: Path) -> list[LogEvent]:
    """Load and parse all events from a JSON log file.

    Supports both a JSON array of events and newline-delimited JSON (NDJSON).
    """
    text = log_path.read_text(encoding="utf-8")
    entries: list[dict] = []

    text_stripped = text.strip()
    if text_stripped.startswith("["):
        entries = json.loads(text_stripped)
    else:
        for line in text_stripped.splitlines():
            line = line.strip()
            if line:
                entries.append(json.loads(line))

    events = [parse_event(e) for e in entries]
    events.sort(key=lambda e: e.timestamp)
    return events


def stream_events(log_path: Path) -> Iterator[LogEvent]:
    """Stream events one at a time for memory-efficient processing."""
    with open(log_path, encoding="utf-8") as f:
        first_char = f.read(1)
        f.seek(0)

        if first_char == "[":
            entries = json.load(f)
            for entry in entries:
                yield parse_event(entry)
        else:
            for line in f:
                line = line.strip()
                if line:
                    yield parse_event(json.loads(line))
